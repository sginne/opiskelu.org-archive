/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yahtzee;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import org.ini4j.InvalidFileFormatException;
import org.ini4j.Wini;


/**
 *
 * @author SiGiN
 */
public class BattleField extends javax.swing.JFrame {

    public int turnState;
    /**
     *
     */
    public int DiceThrow()
    {
        Random  randomizer = new Random(); 
        return randomizer.nextInt(6)+1;
        
    }
    public class PlayerRecord {

        /**
         *
         */
        public String name;
        public int ones;
        public int twoes;
        public int threes;
        public int fours;
        public int fives;
        public int sixes;
        public int threekind;
        public int fourkind;
        public int fullhouse;
        public int small;
        public int large;
        public int yahtzee;
        public int chance;
        public int bonus()
        {
            int littlePoints=0;
            if (this.ones>0){littlePoints += this.ones;}
            if (this.twoes>0){littlePoints += this.twoes;}
            if (this.threes>0){littlePoints += this.threes;}
            if (this.fours>0){littlePoints += this.fours;}
            if (this.fives>0){littlePoints += this.fives;}
            if (this.sixes>0){littlePoints += this.sixes;}
            if (littlePoints>62){return 50;}
            else{return 0;}
            
        }
        public boolean hasFinished ()
        {
            boolean returnFlag=true;
            if (this.ones==-1) returnFlag=false;
            if (this.twoes==-1) returnFlag=false;
            if (this.threes==-1) returnFlag=false;
            if (this.fours==-1) returnFlag=false;
            if (this.fives==-1) returnFlag=false;
            if (this.sixes==-1) returnFlag=false;
            
            if (this.threekind==-1) returnFlag=false;
            if (this.fourkind==-1) returnFlag=false;
            if (this.fullhouse==-1) returnFlag=false;
            if (this.small==-1) returnFlag=false;
            if (this.large==-1) returnFlag=false;
            if (this.yahtzee==-1) returnFlag=false;
            if (this.chance==-1) returnFlag=false;
            
            return returnFlag;
        }
        public int score(){
            int allPoints=0;
            if (this.ones>0) allPoints+=this.ones;
            if (this.twoes>0) allPoints+=this.twoes;
            if (this.threes>0) allPoints+=this.threes;
            if (this.fours>0) allPoints+=this.fours;
            if (this.fives>0) allPoints+=this.fives;
            if (this.sixes>0) allPoints+=this.sixes;
            allPoints+=this.bonus();
            
            if (this.threekind>0) allPoints+=this.threekind;
            if (this.fourkind>0) allPoints+=this.fourkind;
            if (this.fullhouse>0) allPoints+=this.fullhouse;
            if (this.small>0) allPoints+=this.small;
            if (this.large>0) allPoints+=this.large;
            if (this.yahtzee>0) allPoints+=this.yahtzee;
            if (this.chance>0) allPoints+=this.chance;
            
            
            
            
            return allPoints;
        }

    }
        public int onesScore(){
            int points=0;
            if ("1".equals(diceALabel.getText())) points+=1;
            if ("1".equals(diceBLabel.getText())) points+=1;          
            if ("1".equals(diceCLabel.getText())) points+=1;
            if ("1".equals(diceDLabel.getText())) points+=1;
            if ("1".equals(diceELabel.getText())) points+=1;
            return points;
        }
        public int twoesScore(){
            int points=0;
            if ("2".equals(diceALabel.getText())) points+=2;
            if ("2".equals(diceBLabel.getText())) points+=2;          
            if ("2".equals(diceCLabel.getText())) points+=2;
            if ("2".equals(diceDLabel.getText())) points+=2;
            if ("2".equals(diceELabel.getText())) points+=2;
            return points;
        }
        public int threesScore(){
            int points=0;
            if ("3".equals(diceALabel.getText())) points+=3;
            if ("3".equals(diceBLabel.getText())) points+=3;          
            if ("3".equals(diceCLabel.getText())) points+=3;
            if ("3".equals(diceDLabel.getText())) points+=3;
            if ("3".equals(diceELabel.getText())) points+=3;
            return points;
        }
        public int foursScore(){
            int points=0;
            if ("4".equals(diceALabel.getText())) points+=4;
            if ("4".equals(diceBLabel.getText())) points+=4;          
            if ("4".equals(diceCLabel.getText())) points+=4;
            if ("4".equals(diceDLabel.getText())) points+=4;
            if ("4".equals(diceELabel.getText())) points+=4;
            return points;
        }
        public int fivesScore(){
            int points=0;
            if ("5".equals(diceALabel.getText())) points+=5;
            if ("5".equals(diceBLabel.getText())) points+=5;          
            if ("5".equals(diceCLabel.getText())) points+=5;
            if ("5".equals(diceDLabel.getText())) points+=5;
            if ("5".equals(diceELabel.getText())) points+=5;
            return points;
        }
        public int sixesScore(){
            int points=0;
            if ("6".equals(diceALabel.getText())) points+=6;
            if ("6".equals(diceBLabel.getText())) points+=6;          
            if ("6".equals(diceCLabel.getText())) points+=6;
            if ("6".equals(diceDLabel.getText())) points+=6;
            if ("6".equals(diceELabel.getText())) points+=6;
            return points;
        }
        public int threekindScore(){
            int points=0;
            int[] counterArray = new int[]{0,0,0,0,0,0};
            counterArray[Integer.parseInt(diceALabel.getText())-1]+=1;
            counterArray[Integer.parseInt(diceBLabel.getText())-1]+=1;
            counterArray[Integer.parseInt(diceCLabel.getText())-1]+=1;
            counterArray[Integer.parseInt(diceDLabel.getText())-1]+=1;
            counterArray[Integer.parseInt(diceELabel.getText())-1]+=1;
            for (int i = 0; i < 6; i++) {
                if (counterArray[i]>2){
                    points+=(i+1)*3;
                    points=this.chanceScore();
                }
                    
            }
            return points;
        }

        public int fourkindScore(){
            int points=0;
            int[] counterArray = new int[]{0,0,0,0,0,0};
            counterArray[Integer.parseInt(diceALabel.getText())-1]+=1;
            counterArray[Integer.parseInt(diceBLabel.getText())-1]+=1;
            counterArray[Integer.parseInt(diceCLabel.getText())-1]+=1;
            counterArray[Integer.parseInt(diceDLabel.getText())-1]+=1;
            counterArray[Integer.parseInt(diceELabel.getText())-1]+=1;
            //System.out.println(Arrays.toString(counterArray));
            for (int i = 0; i < 6; i++) {
                if (counterArray[i]>3){
                    points+=(i+1)*4;
                    points=this.chanceScore();
                }
                    
            }
            return points;
        }
    public int fullhouseScore() {
        int points = 0;
        int[] counterArray = new int[]{0, 0, 0, 0, 0, 0};
        counterArray[Integer.parseInt(diceALabel.getText()) - 1] += 1;
        counterArray[Integer.parseInt(diceBLabel.getText()) - 1] += 1;
        counterArray[Integer.parseInt(diceCLabel.getText()) - 1] += 1;
        counterArray[Integer.parseInt(diceDLabel.getText()) - 1] += 1;
        counterArray[Integer.parseInt(diceELabel.getText()) - 1] += 1;
        Arrays.sort(counterArray);
        //System.out.println(Arrays.toString(counterArray));
        if ((counterArray[5] == 3) && (counterArray[4] == 2)) {
            points = 25;
        }
        return points;
    }
        public int smallScore() {
        int points = 0;
        int[] counterArray = new int[]{0, 0, 0, 0, 0, 0};
        counterArray[Integer.parseInt(diceALabel.getText()) - 1] += 1;
        counterArray[Integer.parseInt(diceBLabel.getText()) - 1] += 1;
        counterArray[Integer.parseInt(diceCLabel.getText()) - 1] += 1;
        counterArray[Integer.parseInt(diceDLabel.getText()) - 1] += 1;
        counterArray[Integer.parseInt(diceELabel.getText()) - 1] += 1;
        
        //System.out.println(Arrays.toString(counterArray));
        if ((counterArray[0] >= 1) && (counterArray[1] >= 1)&& (counterArray[2] >= 1)&& (counterArray[3] >= 1)) {
            points = 30;
        }
        if ((counterArray[4] >= 1) && (counterArray[1] >= 1)&& (counterArray[2] >= 1)&& (counterArray[3] >= 1)) {
            points = 30;
        }
        if ((counterArray[4] >= 1) && (counterArray[5] >= 1)&& (counterArray[2] >= 1)&& (counterArray[3] >= 1)) {
            points = 30;
        }
        
        
        return points;
    }
    public int largeScore() {
        int points = 0;
        int[] counterArray = new int[]{0, 0, 0, 0, 0, 0};
        counterArray[Integer.parseInt(diceALabel.getText()) - 1] += 1;
        counterArray[Integer.parseInt(diceBLabel.getText()) - 1] += 1;
        counterArray[Integer.parseInt(diceCLabel.getText()) - 1] += 1;
        counterArray[Integer.parseInt(diceDLabel.getText()) - 1] += 1;
        counterArray[Integer.parseInt(diceELabel.getText()) - 1] += 1;
        Arrays.sort(counterArray);
        //System.out.println(Arrays.toString(counterArray));
        if ((counterArray[0] >= 1) && (counterArray[1] >= 1)&& (counterArray[2] >= 1)&& (counterArray[3] >= 1)&& (counterArray[4] >= 1)) {
            points = 40;
        }
        if ((counterArray[5] >= 1) && (counterArray[1] >= 1)&& (counterArray[2] >= 1)&& (counterArray[3] >= 1)&& (counterArray[4] >= 1)) {
            points = 40;
        }

        return points;
    }


        public int yahtzeeScore(){
            int points=0;
            int[] counterArray = new int[]{0,0,0,0,0,0};
            counterArray[Integer.parseInt(diceALabel.getText())-1]+=1;
            counterArray[Integer.parseInt(diceBLabel.getText())-1]+=1;
            counterArray[Integer.parseInt(diceCLabel.getText())-1]+=1;
            counterArray[Integer.parseInt(diceDLabel.getText())-1]+=1;
            counterArray[Integer.parseInt(diceELabel.getText())-1]+=1;
            //System.out.println(Arrays.toString(counterArray));
            for (int i = 0; i < 6; i++) {
                if (counterArray[i]>4){
                    points=50;
                }
                    
            }
            return points;
        }
        public int chanceScore(){
            int points=Integer.parseInt(diceALabel.getText())+Integer.parseInt(diceBLabel.getText())+Integer.parseInt(diceCLabel.getText())+Integer.parseInt(diceDLabel.getText())+Integer.parseInt(diceELabel.getText());
            return points;
        }
    public void updateChoice(PlayerRecord whoChoose){
        DefaultTableModel model = (DefaultTableModel) choiceTable.getModel();
        model.setRowCount(0);
        if (whoChoose.ones==-1){ model.addRow(new Object[]{"Ones",  onesScore()});}
        if (whoChoose.twoes==-1){ model.addRow(new Object[]{"Twos",  twoesScore()});}
        if (whoChoose.threes==-1){ model.addRow(new Object[]{"Threes",  threesScore()});}
        if (whoChoose.fours==-1){ model.addRow(new Object[]{"Fours",  foursScore()});}
        if (whoChoose.fives==-1){ model.addRow(new Object[]{"Fives", fivesScore()});}
        if (whoChoose.sixes==-1){ model.addRow(new Object[]{"Sixes", sixesScore()});}
        if (whoChoose.threekind==-1){ model.addRow(new Object[]{"Three-kind", threekindScore()});}
        if (whoChoose.fourkind==-1){ model.addRow(new Object[]{"Four-kind", fourkindScore()});}
        if (whoChoose.fullhouse==-1){ model.addRow(new Object[]{"Fullhouse", fullhouseScore()});}
        if (whoChoose.small==-1){ model.addRow(new Object[]{"Small", smallScore()});}
        if (whoChoose.large==-1){ model.addRow(new Object[]{"Large", largeScore()});}
        if (whoChoose.yahtzee==-1){ model.addRow(new Object[]{"Yahtzee", yahtzeeScore()});}
        if (whoChoose.chance==-1){ model.addRow(new Object[]{"Chance", chanceScore()});}
        
        
        if (choiceTable.isEnabled()) choiceTable.setRowSelectionInterval(0, 0);
        else choiceTable.getSelectionModel().clearSelection();
    }

    //public String playerOneName;
    //public String playerTwoName;
    public PlayerRecord playerOneRecord = new PlayerRecord();
    public PlayerRecord playerTwoRecord = new PlayerRecord();
    //public GameInfo gameInfo; useless
    public void MakeRoll(){
        if (!diceAHold.isSelected()){
            diceALabel.setText(Integer.toHexString(DiceThrow()));
        }
        if (!diceBHold.isSelected()){
            diceBLabel.setText(Integer.toHexString(DiceThrow()));
        }
        if (!diceCHold.isSelected()){
            diceCLabel.setText(Integer.toHexString(DiceThrow()));
        }
        if (!diceDHold.isSelected()){
            diceDLabel.setText(Integer.toHexString(DiceThrow()));
        }
        if (!diceEHold.isSelected()){
            diceELabel.setText(Integer.toHexString(DiceThrow()));
        }

    }
    public void PlayGame(){
        
    }
    
    public void InitPlayerOne(String name) {
        playerOneRecord.name = name;
        playerOneRecord.ones = -1;
        //System.out.println(playerOneRecord.ones);
        playerOneRecord.twoes = -1;
        playerOneRecord.threes = -1;
        playerOneRecord.fours = -1;
        playerOneRecord.fives = -1;
        playerOneRecord.sixes = -1;
        playerOneRecord.threekind=-1;
        playerOneRecord.fourkind=-1;
        playerOneRecord.fullhouse=-1;
        playerOneRecord.small=-1;
        playerOneRecord.large=-1;
        playerOneRecord.yahtzee=-1;
        playerOneRecord.chance=-1;
        //playerOneLabel.setText(name);

        //jTable1.setValueAt("Ones", 0, 0);
    }

    public void InitPlayerTwo(String name) {
        playerTwoRecord.name = name;
        playerTwoRecord.ones = -1;
        playerTwoRecord.twoes = -1;
        playerTwoRecord.threes = -1;
        playerTwoRecord.fours = -1;
        playerTwoRecord.fives = -1;
        playerTwoRecord.sixes = -1;
        playerTwoRecord.threekind=-1;
        playerTwoRecord.fourkind=-1;
        playerTwoRecord.fullhouse=-1;
        playerTwoRecord.small=-1;
        playerTwoRecord.large=-1;
        playerTwoRecord.yahtzee=-1;
        playerTwoRecord.chance=-1;

    }
    public void UpdateScoreboards(){
        if (((turnState>=11)&&(turnState<=13))||((turnState>=21)&&(turnState<=23)))
        {
            rollBtn.setEnabled(true);
            choiceTable.setEnabled(false);
            choiceBtn.setEnabled(false);
        }
        if((turnState==14)||(turnState==24))
        {
            rollBtn.setEnabled(false);
            choiceTable.setEnabled(true);
            choiceBtn.setEnabled(true);
        }
        
        playerOneLabel.setText(playerOneRecord.name+" ("+Integer.toString(playerOneRecord.score())+")");
        playerTwoLabel.setText(playerTwoRecord.name+" ("+Integer.toString(playerTwoRecord.score())+")");
        if (turnState<17){
          turnIndicator.setText(playerOneRecord.name);
            updateChoice(playerOneRecord);
        }else{
          turnIndicator.setText(playerTwoRecord.name); 
            updateChoice(playerTwoRecord);
        }
        playerOneBoard.setValueAt("Ones", 0, 0);
        playerOneBoard.setValueAt("Twos", 1, 0);
        playerOneBoard.setValueAt("Threes", 2, 0);
        playerOneBoard.setValueAt("Fours", 3, 0);
        playerOneBoard.setValueAt("Fives", 4, 0);
        playerOneBoard.setValueAt("Sixes", 5, 0);
        playerOneBoard.setValueAt("Three-kind", 6, 0);
        playerOneBoard.setValueAt("Four-kind", 7, 0);
        playerOneBoard.setValueAt("Fullhouse", 8, 0);
        playerOneBoard.setValueAt("Small", 9, 0);
        playerOneBoard.setValueAt("Large", 10, 0);
        playerOneBoard.setValueAt("Yahtzee", 11, 0);
        playerOneBoard.setValueAt("Chance", 12, 0);
        playerTwoBoard.setValueAt("Ones", 0, 0);
        playerTwoBoard.setValueAt("Twos", 1, 0);
        playerTwoBoard.setValueAt("Threes", 2, 0);
        playerTwoBoard.setValueAt("Fours", 3, 0);
        playerTwoBoard.setValueAt("Fives", 4, 0);
        playerTwoBoard.setValueAt("Sixes", 5, 0);
        playerTwoBoard.setValueAt("Three-kind", 6, 0);
        playerTwoBoard.setValueAt("Four-kind", 7, 0);
        playerTwoBoard.setValueAt("Fullhouse", 8, 0);
        playerTwoBoard.setValueAt("Small", 9, 0);
        playerTwoBoard.setValueAt("Large", 10, 0);
        playerTwoBoard.setValueAt("Yahtzee", 11, 0);
        playerTwoBoard.setValueAt("Chance", 12, 0);
        
        
        if (playerOneRecord.ones < 0) {
            playerOneBoard.setValueAt("x", 0, 1);
        } else {
            playerOneBoard.setValueAt(playerOneRecord.ones, 0, 1);
        }
        if (playerOneRecord.twoes < 0) {
            playerOneBoard.setValueAt("x", 1, 1);
        } else {
            playerOneBoard.setValueAt(playerOneRecord.twoes, 1, 1);
        }
        if (playerOneRecord.threes < 0) {
            playerOneBoard.setValueAt("x", 2, 1);
        } else {
            playerOneBoard.setValueAt(playerOneRecord.threes, 2, 1);
        }
        if (playerOneRecord.fours < 0) {
            playerOneBoard.setValueAt("x", 3, 1);
        } else {
            playerOneBoard.setValueAt(playerOneRecord.fours, 3, 1);
        }
        if (playerOneRecord.fives < 0) {
            playerOneBoard.setValueAt("x", 4, 1);
        } else {
            playerOneBoard.setValueAt(playerOneRecord.fives, 4, 1);
        }
        if (playerOneRecord.sixes < 0) {
            playerOneBoard.setValueAt("x", 5, 1);
        } else {
            playerOneBoard.setValueAt(playerOneRecord.sixes, 5, 1);
        }
        if (playerTwoRecord.ones < 0) {
            playerTwoBoard.setValueAt("x", 0, 1);
        } else {
            playerTwoBoard.setValueAt(playerTwoRecord.ones, 0, 1);
        }
        if (playerTwoRecord.twoes < 0) {
            playerTwoBoard.setValueAt("x", 1, 1);
        } else {
            playerTwoBoard.setValueAt(playerTwoRecord.twoes, 1, 1);
        }
        if (playerTwoRecord.threes < 0) {
            playerTwoBoard.setValueAt("x", 2, 1);
        } else {
            playerTwoBoard.setValueAt(playerTwoRecord.threes, 2, 1);
        }
        if (playerTwoRecord.fours < 0) {
            playerTwoBoard.setValueAt("x", 3, 1);
        } else {
            playerTwoBoard.setValueAt(playerTwoRecord.fours, 3, 1);
        }
        if (playerTwoRecord.fives < 0) {
            playerTwoBoard.setValueAt("x", 4, 1);
        } else {
            playerTwoBoard.setValueAt(playerTwoRecord.fives, 4, 1);
        }
        if (playerTwoRecord.sixes < 0) {
            playerTwoBoard.setValueAt("x", 5, 1);
        } else {
            playerTwoBoard.setValueAt(playerTwoRecord.sixes, 5, 1);
        }
        
        if (playerOneRecord.threekind<0){
            playerOneBoard.setValueAt("x", 6, 1);
        }
        else
        {
            playerOneBoard.setValueAt(playerOneRecord.threekind, 6, 1);
        }
        if (playerOneRecord.fourkind<0){
            playerOneBoard.setValueAt("x", 7, 1);
        }
        else
        {
            playerOneBoard.setValueAt(playerOneRecord.fourkind, 7, 1);
        }
        if (playerOneRecord.fullhouse<0){
            playerOneBoard.setValueAt("x", 8, 1);
        }
        else
        {
            playerOneBoard.setValueAt(playerOneRecord.fullhouse, 8, 1);
        }
        if (playerOneRecord.small<0){
            playerOneBoard.setValueAt("x", 9, 1);
        }
        else
        {
            playerOneBoard.setValueAt(playerOneRecord.small, 9, 1);
        }
        if (playerOneRecord.large<0){
            playerOneBoard.setValueAt("x", 10, 1);
        }
        else
        {
            playerOneBoard.setValueAt(playerOneRecord.large, 10, 1);
        }
        if (playerOneRecord.yahtzee<0){
            playerOneBoard.setValueAt("x", 11, 1);
        }
        else
        {
            playerOneBoard.setValueAt(playerOneRecord.yahtzee, 11, 1);
        }
        if (playerOneRecord.chance<0){
            playerOneBoard.setValueAt("x", 12, 1);
        }
        else
        {
            playerOneBoard.setValueAt(playerOneRecord.chance, 12, 1);
        }
        if (playerTwoRecord.threekind<0){
            playerTwoBoard.setValueAt("x", 6, 1);
        }
        else
        {
            playerTwoBoard.setValueAt(playerTwoRecord.threekind, 6, 1);
        }
        if (playerTwoRecord.fourkind<0){
            playerTwoBoard.setValueAt("x", 7, 1);
        }
        else
        {
            playerTwoBoard.setValueAt(playerTwoRecord.fourkind, 7, 1);
        }
        if (playerTwoRecord.fullhouse<0){
            playerTwoBoard.setValueAt("x", 8, 1);
        }
        else
        {
            playerTwoBoard.setValueAt(playerTwoRecord.fullhouse, 8, 1);
        }
        if (playerTwoRecord.small<0){
            playerTwoBoard.setValueAt("x", 9, 1);
        }
        else
        {
            playerTwoBoard.setValueAt(playerTwoRecord.small, 9, 1);
        }
        if (playerTwoRecord.large<0){
            playerTwoBoard.setValueAt("x", 10, 1);
        }
        else
        {
            playerTwoBoard.setValueAt(playerTwoRecord.large, 10, 1);
        }
        if (playerTwoRecord.yahtzee<0){
            playerTwoBoard.setValueAt("x", 11, 1);
        }
        else
        {
            playerTwoBoard.setValueAt(playerTwoRecord.yahtzee, 11, 1);
        }
        if (playerTwoRecord.chance<0){
            playerTwoBoard.setValueAt("x", 12, 1);
        }
        else
        {
            playerTwoBoard.setValueAt(playerTwoRecord.chance, 12, 1);
        }


       


    }

    /**
     * Creates new form BattleField
     */
    public BattleField() {

        initComponents();

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        playerOneLabel = new javax.swing.JLabel();
        playerTwoLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        playerOneBoard = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        playerTwoBoard = new javax.swing.JTable();
        diceALabel = new javax.swing.JLabel();
        diceBLabel = new javax.swing.JLabel();
        diceCLabel = new javax.swing.JLabel();
        diceDLabel = new javax.swing.JLabel();
        diceELabel = new javax.swing.JLabel();
        diceAHold = new javax.swing.JCheckBox();
        diceBHold = new javax.swing.JCheckBox();
        diceCHold = new javax.swing.JCheckBox();
        diceDHold = new javax.swing.JCheckBox();
        diceEHold = new javax.swing.JCheckBox();
        jLabel1 = new javax.swing.JLabel();
        turnIndicator = new javax.swing.JLabel();
        saveBtn = new javax.swing.JButton();
        debugBtn = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        choiceTable = new javax.swing.JTable();
        rollBtn = new javax.swing.JButton();
        choiceBtn = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        playerOneLabel.setText("pl1");

        playerTwoLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        playerTwoLabel.setText("pl2");

        playerOneBoard.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Combo", "Points"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        playerOneBoard.setColumnSelectionAllowed(true);
        playerOneBoard.setEnabled(false);
        playerOneBoard.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(playerOneBoard);
        playerOneBoard.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (playerOneBoard.getColumnModel().getColumnCount() > 0) {
            playerOneBoard.getColumnModel().getColumn(0).setResizable(false);
            playerOneBoard.getColumnModel().getColumn(1).setResizable(false);
        }

        playerTwoBoard.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Combo", "Points"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        playerTwoBoard.setEnabled(false);
        playerTwoBoard.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(playerTwoBoard);
        playerTwoBoard.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (playerTwoBoard.getColumnModel().getColumnCount() > 0) {
            playerTwoBoard.getColumnModel().getColumn(0).setResizable(false);
            playerTwoBoard.getColumnModel().getColumn(1).setResizable(false);
        }

        diceALabel.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        diceALabel.setText("0");

        diceBLabel.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        diceBLabel.setText("0");

        diceCLabel.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        diceCLabel.setText("0");

        diceDLabel.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        diceDLabel.setText("0");

        diceELabel.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        diceELabel.setText("0");

        diceAHold.setText("Hold");
        diceAHold.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                diceAHoldActionPerformed(evt);
            }
        });

        diceBHold.setText("Hold");
        diceBHold.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                diceBHoldActionPerformed(evt);
            }
        });

        diceCHold.setText("Hold");
        diceCHold.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                diceCHoldActionPerformed(evt);
            }
        });

        diceDHold.setText("Hold");
        diceDHold.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                diceDHoldActionPerformed(evt);
            }
        });

        diceEHold.setText("Hold");
        diceEHold.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                diceEHoldActionPerformed(evt);
            }
        });

        jLabel1.setText("turn to move");

        turnIndicator.setText("player");

        saveBtn.setText("Save&Quit");
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });

        debugBtn.setText("Debug");
        debugBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                debugBtnActionPerformed(evt);
            }
        });

        choiceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "What?", "How much?"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(choiceTable);
        if (choiceTable.getColumnModel().getColumnCount() > 0) {
            choiceTable.getColumnModel().getColumn(0).setResizable(false);
            choiceTable.getColumnModel().getColumn(1).setResizable(false);
        }

        rollBtn.setText("Roll it!");
        rollBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rollBtnActionPerformed(evt);
            }
        });

        choiceBtn.setText("Pick combo");
        choiceBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                choiceBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(39, 39, 39)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(95, 95, 95)
                                        .addComponent(saveBtn))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(rollBtn)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(diceAHold)
                                                        .addComponent(diceALabel))
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(diceBHold)
                                                        .addComponent(diceBLabel))
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(diceCHold)
                                                        .addComponent(diceCLabel)))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(turnIndicator)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jLabel1))))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(diceDHold)
                                            .addComponent(diceDLabel))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(diceELabel)
                                            .addComponent(diceEHold))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(playerOneLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(playerTwoLabel)))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(204, 204, 204)
                                .addComponent(debugBtn))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(choiceBtn)))
                        .addGap(26, 26, 26))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(playerOneLabel)
                    .addComponent(playerTwoLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 244, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(saveBtn)
                        .addGap(50, 50, 50)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(turnIndicator))
                        .addGap(26, 26, 26)
                        .addComponent(rollBtn)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(diceALabel)
                            .addComponent(diceBLabel)
                            .addComponent(diceCLabel)
                            .addComponent(diceDLabel)
                            .addComponent(diceELabel))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(diceAHold)
                            .addComponent(diceBHold)
                            .addComponent(diceCHold)
                            .addComponent(diceDHold)
                            .addComponent(diceEHold))))
                .addGap(18, 18, 18)
                .addComponent(debugBtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 96, Short.MAX_VALUE)
                .addComponent(choiceBtn)
                .addGap(105, 105, 105))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void diceAHoldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_diceAHoldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_diceAHoldActionPerformed

    private void diceBHoldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_diceBHoldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_diceBHoldActionPerformed

    private void diceCHoldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_diceCHoldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_diceCHoldActionPerformed

    private void diceDHoldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_diceDHoldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_diceDHoldActionPerformed

    private void diceEHoldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_diceEHoldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_diceEHoldActionPerformed

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        Wini ini;
        try {
            ini = new Wini(new File("save.ini"));
            ini.put("main", "State", turnState);
            ini.put("dices","diceA",diceALabel.getText());
            ini.put("dices","diceB",diceBLabel.getText());
            ini.put("dices","diceC",diceCLabel.getText());
            ini.put("dices","diceD",diceDLabel.getText());
            ini.put("dices","diceE",diceELabel.getText());
            
            ini.put("player1","name",playerOneRecord.name);
            ini.put("player1","ones",playerOneRecord.ones);
            ini.put("player1","twoes",playerOneRecord.twoes);
            ini.put("player1","threes",playerOneRecord.threes);
            ini.put("player1","fours",playerOneRecord.fours);
            ini.put("player1","fives",playerOneRecord.fives);
            ini.put("player1","sixes",playerOneRecord.sixes);
            ini.put("player1","threekind",playerOneRecord.threekind);
            ini.put("player1","fourkind",playerOneRecord.fourkind);
            ini.put("player1","fullhouse",playerOneRecord.fullhouse);
            ini.put("player1","small",playerOneRecord.small);
            ini.put("player1","large",playerOneRecord.large);
            ini.put("player1","yahtzee",playerOneRecord.yahtzee);
            ini.put("player1","chance",playerOneRecord.chance);
            
            ini.put("player2","name",playerTwoRecord.name);
            ini.put("player2","ones",playerTwoRecord.ones);
            ini.put("player2","twoes",playerTwoRecord.twoes);
            ini.put("player2","threes",playerTwoRecord.threes);
            ini.put("player2","fours",playerTwoRecord.fours);
            ini.put("player2","fives",playerTwoRecord.fives);
            ini.put("player2","sixes",playerTwoRecord.sixes);
            ini.put("player2","threekind",playerTwoRecord.threekind);
            ini.put("player2","fourkind",playerTwoRecord.fourkind);
            ini.put("player2","fullhouse",playerTwoRecord.fullhouse);
            ini.put("player2","small",playerTwoRecord.small);
            ini.put("player2","large",playerTwoRecord.large);
            ini.put("player2","yahtzee",playerTwoRecord.yahtzee);
            ini.put("player2","chance",playerTwoRecord.chance);       
            
            
            ini.store();
            System.exit(0);
        } catch (InvalidFileFormatException e) {
            System.out.println("Invalid file format.");
        } catch (IOException e) {
            System.out.println(e.toString());
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_saveBtnActionPerformed

    private void debugBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_debugBtnActionPerformed
        playerOneRecord.ones=100;
        playerOneRecord.twoes=1;
        playerOneRecord.threes=1;
        playerOneRecord.fours=1;
        playerOneRecord.fives=1;
        playerOneRecord.sixes=1;
        playerOneRecord.threekind=1;
        playerOneRecord.fourkind=1;
        playerOneRecord.fullhouse=1;
        playerOneRecord.small=1;
        playerOneRecord.large=1;
        
        playerOneRecord.yahtzee=1;
        playerOneRecord.chance=1;
        
        playerTwoRecord.ones=1;
        playerTwoRecord.twoes=1;
        playerTwoRecord.threes=1;
        playerTwoRecord.fours=1;
        playerTwoRecord.fives=1;
        playerTwoRecord.sixes=1;
        playerTwoRecord.threekind=1;
        playerTwoRecord.fourkind=1;
        playerTwoRecord.fullhouse=1;
        playerTwoRecord.small=1;
        playerTwoRecord.large=1;
        playerTwoRecord.yahtzee=1;
        playerTwoRecord.chance=-1;
        
        turnState=22;
        UpdateScoreboards();

    }//GEN-LAST:event_debugBtnActionPerformed

    private void rollBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rollBtnActionPerformed
        // TODO add your handling code here:
        MakeRoll();
        turnState+=1;
        //System.out.println(turnState);
        UpdateScoreboards();
    }//GEN-LAST:event_rollBtnActionPerformed

    private void choiceBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_choiceBtnActionPerformed
        // TODO add your handling code here:
      PlayerRecord activePlayer;
      if (turnState<17) activePlayer=playerOneRecord;
      else activePlayer=playerTwoRecord;
      
      
      String choice=(String)choiceTable.getValueAt(choiceTable.getSelectedRow(),0);
      if ("Ones".equals(choice)) {activePlayer.ones=onesScore();}
      if ("Twos".equals(choice)) {activePlayer.twoes=twoesScore();}
      if ("Threes".equals(choice)) {activePlayer.threes=threesScore();}
      if ("Fours".equals(choice)) {activePlayer.fours=foursScore();}
      if ("Fives".equals(choice)) {activePlayer.fives=fivesScore();}
      if ("Sixes".equals(choice)) {activePlayer.sixes=sixesScore();}
      if ("Three-kind".equals(choice)) {activePlayer.threekind=threekindScore();}
      if ("Four-kind".equals(choice)) {activePlayer.fourkind=fourkindScore();}
      if ("Fullhouse".equals(choice)) {activePlayer.fullhouse=fullhouseScore();}
      if ("Small".equals(choice)) {activePlayer.small=smallScore();}
      if ("Large".equals(choice)) {activePlayer.large=largeScore();}
      if ("Yahtzee".equals(choice)) {activePlayer.yahtzee=yahtzeeScore();}
      if ("Chance".equals(choice)) {activePlayer.chance=chanceScore();}
      
      if ((turnState==24)&&(activePlayer.hasFinished()))
      {
          ClaimVictory claimVictory=new ClaimVictory(this, true);
          claimVictory.setLocationRelativeTo(null);
          String winner="";
          String score;
          if (playerOneRecord.score()>playerTwoRecord.score()) winner=playerOneRecord.name+" won!";
          if (playerTwoRecord.score()>playerOneRecord.score()) winner=playerTwoRecord.name+" won!";
          if (playerTwoRecord.score()==playerOneRecord.score()) winner="DRAW";
          score=playerOneRecord.name+"("+Integer.toString(playerOneRecord.score())+") vs."+playerTwoRecord.name+"("+Integer.toString(playerTwoRecord.score())+")";
          claimVictory.scoreText.setText(score);
          claimVictory.bigText.setText(winner);
          claimVictory.updateHall(winner+" Aftermath:"+score+System.getProperty("line.separator"));
          claimVictory.setVisible(true);
          System.exit(0);
          //System.out.println("Ta-daaa!");
      }
      
      diceAHold.setSelected(false);
      diceBHold.setSelected(false);
      diceCHold.setSelected(false);
      diceDHold.setSelected(false);
      diceEHold.setSelected(false);
      MakeRoll();
      if (turnState==14) turnState=21;
      if (turnState==24) turnState=11;
      UpdateScoreboards();
    }//GEN-LAST:event_choiceBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                

}
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BattleField.class  

.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } 

catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BattleField.class  

.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } 

catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BattleField.class  

.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } 

catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BattleField.class  

.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BattleField().setVisible(true);
            }
        });
    }
    


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton choiceBtn;
    private javax.swing.JTable choiceTable;
    private javax.swing.JButton debugBtn;
    private javax.swing.JCheckBox diceAHold;
    public javax.swing.JLabel diceALabel;
    private javax.swing.JCheckBox diceBHold;
    public javax.swing.JLabel diceBLabel;
    private javax.swing.JCheckBox diceCHold;
    public javax.swing.JLabel diceCLabel;
    private javax.swing.JCheckBox diceDHold;
    public javax.swing.JLabel diceDLabel;
    private javax.swing.JCheckBox diceEHold;
    public javax.swing.JLabel diceELabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable playerOneBoard;
    private javax.swing.JLabel playerOneLabel;
    private javax.swing.JTable playerTwoBoard;
    private javax.swing.JLabel playerTwoLabel;
    private javax.swing.JButton rollBtn;
    private javax.swing.JButton saveBtn;
    private javax.swing.JLabel turnIndicator;
    // End of variables declaration//GEN-END:variables
}
